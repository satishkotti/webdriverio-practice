var Q = require('Q');
var chai = require("chai");
var should = chai.should();
var webdriverio = require("webdriverio");
var urls1 = require("./../../../config/DFP1");
var urls2 = require("./../../../config/DFP2");
//var urls1 = require("./../../../config/DFPAdcallstestdata");
//var urls2 = require("./../../../config/DFPAdcallstestdata.1");
var ada = require("./../../../common/functions/AdcallsActions");
var browser = require('./browser');
var webmd_proxy = require("wdio-browser-proxy")(browser);
var qs = require("querystring");
var res;

module.exports = {

omniture:function(browser){
var deferred = Q.defer()
browser.enableProxy({})//.then(function () { console.log('finsihed enabling proxy'); })
          .url('http://www.webmd.com/diet/rm-quiz-caffeine-myths')
           .click('//*[@id="ContentPane28"]/div/ul/li[2]/a/span')
           .pause(3000)
            .end()
            .getNetworkCalls('http://std.o.webmd.com').then(function(result){
                console.log("sasi"+result);
                    deferred.resolve(result);
            });
        return deferred.promise;                 
                }
    }
